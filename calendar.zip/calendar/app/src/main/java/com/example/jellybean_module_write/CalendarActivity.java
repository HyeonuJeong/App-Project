package com.example.jellybean_module_write;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.CalendarView;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;

import java.io.File;

public class CalendarActivity extends MainActivity{

    private static final String TAG = "CalendarActivity";

    private CalendarView mCalendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        mCalendarView = (CalendarView)findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView calendarView, int i, int i1, int i2) {
                ImageView imageView = findViewById(R.id.image);
                EditText editText = (EditText) findViewById(R.id.editText);
                String date = i + "-" + (i1+1) + "-" + i2;
                Log.d(TAG, "onSelectedDayChange : date: " + date);
                Intent intent = new Intent(CalendarActivity.this, MainActivity.class);
                intent.putExtra("date",date);

                startActivity(intent);

            }

        });
    }
}


