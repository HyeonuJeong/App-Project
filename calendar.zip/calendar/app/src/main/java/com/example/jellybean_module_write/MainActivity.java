package com.example.jellybean_module_write;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {


    private static final int REQUEST_CODE = 0;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        imageView = findViewById(R.id.image);
        TextView txtToday = (TextView) findViewById(R.id.txtToday);
        EditText editText = (EditText) findViewById(R.id.editText);

        Intent incomingIntent = getIntent();
        String date = incomingIntent.getStringExtra("date");
        txtToday.setText(date);
        txtToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, CalendarActivity.class);

                startActivity(intent);
            }
        });


        Button btnWrite = (Button) findViewById(R.id.btnWrite) ;
        btnWrite.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("Jelly", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                EditText editText = (EditText) findViewById(R.id.editText);
                TextView txtToday = (TextView) findViewById(R.id.txtToday);

                String text = editText.getText().toString();

                editor.putString(txtToday.getText().toString()+"_text", text);
                Toast.makeText(MainActivity.this,"저장 되었습니다.", Toast.LENGTH_LONG).show();
                editor.commit();

            }
        });


        SharedPreferences sf = getSharedPreferences("Jelly", MODE_PRIVATE);
        String text = sf.getString(txtToday.getText().toString()+"_text", "");
        String Date = txtToday.getText().toString();
        File sdCard = Environment.getExternalStorageDirectory();
        File imgFile = new  File(sdCard.getAbsolutePath() + "/JellyBean/" + Date +".jpg");
        if(imgFile.exists()){
            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            imageView.setImageBitmap(myBitmap);
            imageView.setVisibility(View.VISIBLE);
        }
        else{
            imageView.setVisibility(View.GONE);
        }
        editText.setText(text);





        Button btnGallery = (Button) findViewById(R.id.btnGallery) ;
        btnGallery.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
    }



    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == REQUEST_CODE)
        {
            if(resultCode == RESULT_OK)
            {
                try{
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();

                    imageView.setImageBitmap(img);
                    imageView.setVisibility(View.VISIBLE);

                    BitmapDrawable draw = (BitmapDrawable) imageView.getDrawable();
                    Bitmap bitmap = draw.getBitmap();

                    TextView textView = (TextView) findViewById(R.id.txtToday);
                    String Date = textView.getText().toString();

                    FileOutputStream out = null;
                    File sdCard = Environment.getExternalStorageDirectory();
                    File dir = new File(sdCard.getAbsolutePath() + "/JellyBean");
                    dir.mkdirs();
                    String fileName = Date + ".jpg";
                    File outFile = new File(dir, fileName);
                    out = new FileOutputStream(outFile);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
                    out.flush();
                    out.close();

                }

                catch(Exception e) {
                    Toast.makeText(this, "이미지 실패", Toast.LENGTH_LONG).show();
                }
            }
            else if(resultCode == RESULT_CANCELED)
            {
                Toast.makeText(this, "사진 선택 취소", Toast.LENGTH_LONG).show();
                imageView.setVisibility(View.GONE);
            }
        }
    }


}